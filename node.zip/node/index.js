const fs = require('fs');
const http = require('http');

const hostname = 'localhost';
const port = 3000;

const readJson = (filename) => {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, (err, data) => {
            if (err) reject(err);
            else resolve(JSON.parse(data));
        });
    });
};

const writeJson = (filename, data) => {
    return new Promise((resolve, reject) => {
        fs.writeFile(filename, JSON.stringify(data, null, 2), (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
};

const editAndSortJson = (data) => {
  return new Promise((resolve, reject) => {
          const stockAmounts = {
              top1: 12,
              top2: 13,
              top3: 50,
              top4: 22,
              top5: 55,
              top6: 87,
              top7: 12,
              top8: 29,
              top9: 10
          };
          
          const dataArray = Object.keys(data).map(key => ({
              id: key,
              ...data[key],
              stock: stockAmounts[key] || 0  
          }));
          
          const sortedData = {};
          dataArray.forEach(item => {
              sortedData[item.id] = {
                  brandname: item.brandname,
                  price: item.price,
                  pic: item.pic,
                  stock: item.stock 
              };
          });

          resolve(sortedData); 

  });
};


const server = http.createServer((req, res) => {
  new Promise((resolve, reject) => {
    readJson('cloth1.json')
      .then(data => editAndSortJson(data))
      .then(sortedData => writeJson('new_cloth.json', sortedData).then((out) => console.log(out)))
      .catch(err => {
        reject(err);
      });
      resolve('save');
  })
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
